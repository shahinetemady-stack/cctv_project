"""
python add_sales_pages.py
اضافه کردن صفحات فروش و گزارشات مالی به App.jsx
اجرا در پوشه cctv_shop
"""
import os, shutil

FRONTEND = os.path.join('..', 'cctv_frontend', 'src')
pages_admin = os.path.join(FRONTEND, 'pages', 'admin')

# کپی فایل‌ها
for fname in ['SaleInvoicePage.jsx', 'FinancialReportsPage.jsx']:
    src = fname
    dst = os.path.join(pages_admin, fname)
    shutil.copy(src, dst)
    print(f"✓ {fname} کپی شد")

# آپدیت App.jsx
app_path = os.path.join(FRONTEND, 'App.jsx')
with open(app_path, encoding='utf-8') as f:
    app = f.read()

if 'SaleInvoicePage' not in app:
    app = app.replace(
        "import ReportsPage",
        "import SaleInvoicePage from './pages/admin/SaleInvoicePage'\nimport FinancialReportsPage from './pages/admin/FinancialReportsPage'\nimport ReportsPage"
    )
    app = app.replace(
        '<Route path="admin/reports"',
        '<Route path="admin/sales" element={<RequireAuth><SaleInvoicePage /></RequireAuth>} />\n        <Route path="admin/financial" element={<RequireAuth><FinancialReportsPage /></RequireAuth>} />\n        <Route path="admin/reports"'
    )
    with open(app_path, 'w', encoding='utf-8') as f:
        f.write(app)
    print("✓ App.jsx آپدیت شد")
    print("\nآدرس‌های جدید:")
    print("  /admin/sales     — فاکتورهای فروش")
    print("  /admin/financial — گزارشات مالی (سود/زیان + تراز)")
else:
    print("✓ قبلاً اضافه شده بود")
