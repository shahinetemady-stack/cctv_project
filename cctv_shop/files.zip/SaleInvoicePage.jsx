import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import api from '../../services/api'

function fmt(n) { return Number(n || 0).toLocaleString('fa-IR') }

const STATUS_COLORS = {
  draft: '#888', confirmed: '#0066FF', paid: '#00C896', cancelled: '#FF3B3B',
}
const STATUS_LABELS = {
  draft: 'پیش‌نویس', confirmed: 'تأیید شده', paid: 'تسویه شده', cancelled: 'لغو شده',
}

// ─── جزئیات فاکتور ──────────────────────────────────────────
function InvoiceDetail({ id, onClose }) {
  const qc = useQueryClient()
  const { data: inv, isLoading } = useQuery({
    queryKey: ['sale-invoice', id],
    queryFn: () => api.get(`/accounting/sale-invoices/${id}/`).then(r => r.data),
  })
  const { data: accounts = [] } = useQuery({
    queryKey: ['accounts'],
    queryFn: () => api.get('/accounting/accounts/').then(r => r.data),
  })

  const [payForm, setPayForm] = useState({ show: false, method: 'transfer', amount: '', to_account_id: '', date: new Date().toISOString().split('T')[0], reference: '' })
  const [msg, setMsg] = useState(null)

  const payMut = useMutation({
    mutationFn: (d) => api.post('/accounting/sale-payments/', d).then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries(['sale-invoice', id])
      qc.invalidateQueries(['sale-invoices'])
      setPayForm(f => ({ ...f, show: false, amount: '', reference: '' }))
      setMsg({ type: 'success', text: 'پرداخت ثبت شد' })
      setTimeout(() => setMsg(null), 2000)
    },
    onError: (e) => setMsg({ type: 'error', text: e.response?.data?.error || 'خطا' }),
  })

  const statusMut = useMutation({
    mutationFn: (s) => api.patch(`/accounting/sale-invoices/${id}/`, { status: s }).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries(['sale-invoice', id]); qc.invalidateQueries(['sale-invoices']) },
  })

  if (isLoading) return <div className="text-center py-8 text-gray-steel">در حال بارگذاری...</div>
  if (!inv) return null

  return (
    <div className="space-y-4">
      {/* هدر */}
      <div className="card p-5">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h2 className="font-bold text-white text-xl">{inv.invoice_number}</h2>
            <div className="text-xs text-gray-steel mt-1">
              {inv.source_display} | صادرکننده: {inv.created_by} | {inv.created_at}
            </div>
            <div className="text-sm text-white mt-1">{inv.customer_name} | {inv.customer_phone}</div>
            {inv.order_number && <div className="text-xs text-blue-400 mt-0.5">سفارش: {inv.order_number}</div>}
          </div>
          <div className="flex items-center gap-3">
            <span style={{ color: STATUS_COLORS[inv.status], background: STATUS_COLORS[inv.status] + '20', padding: '4px 12px', borderRadius: 20, fontSize: 12 }}>
              {inv.status_display}
            </span>
            <button onClick={onClose} className="text-gray-steel hover:text-white">✕</button>
          </div>
        </div>

        {/* خلاصه مالی */}
        <div className="grid grid-cols-5 gap-3">
          {[
            { label: 'جمع کل', value: fmt(inv.subtotal) + ' ت', color: '#fff' },
            { label: 'تخفیف', value: fmt(inv.discount_amount) + ' ت', color: '#FF9500' },
            { label: 'مبلغ نهایی', value: fmt(inv.total_amount) + ' ت', color: '#0066FF' },
            { label: 'پرداخت شده', value: fmt(inv.paid_amount) + ' ت', color: '#00C896' },
            { label: 'مانده', value: fmt(inv.remaining_amount) + ' ت', color: inv.remaining_amount > 0 ? '#FF3B3B' : '#00C896' },
          ].map(item => (
            <div key={item.label} className="bg-white/5 rounded-lg p-3 text-center">
              <div className="text-[10px] text-gray-steel mb-1">{item.label}</div>
              <div className="text-sm font-bold" style={{ color: item.color }}>{item.value}</div>
            </div>
          ))}
        </div>

        {/* سود */}
        <div className="mt-3 flex gap-4 text-xs">
          <span className="text-gray-steel">بهای تمام شده: <span className="text-white">{fmt(inv.total_cost)} ت</span></span>
          <span className="text-gray-steel">سود ناخالص: <span className={inv.gross_profit >= 0 ? 'text-green-400' : 'text-red-400'}>{fmt(inv.gross_profit)} ت</span></span>
        </div>

        {/* وضعیت */}
        <div className="flex gap-2 mt-4">
          {['draft', 'confirmed', 'paid', 'cancelled'].map(s => (
            <button key={s} onClick={() => statusMut.mutate(s)}
              disabled={inv.status === s}
              style={{ borderColor: inv.status === s ? STATUS_COLORS[s] : 'transparent', color: STATUS_COLORS[s] }}
              className="text-xs px-3 py-1.5 rounded-lg border-2 bg-white/5 disabled:opacity-100 hover:bg-white/10 transition-all">
              {STATUS_LABELS[s]}
            </button>
          ))}
        </div>
      </div>

      {/* اقلام */}
      <div className="card p-5">
        <h3 className="text-sm font-semibold text-white mb-3">اقلام فاکتور</h3>
        <div className="overflow-x-auto">
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
            <thead>
              <tr style={{ borderBottom: '0.5px solid rgba(255,255,255,0.1)' }}>
                {['کالا', 'SKU', 'تعداد', 'قیمت واحد', 'تخفیف%', 'جمع', 'بهای تمام شده', 'سود'].map(h => (
                  <th key={h} style={{ padding: '6px 10px', textAlign: 'right', color: 'var(--color-text-secondary)', fontWeight: 500, whiteSpace: 'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {inv.items?.map((item, i) => (
                <tr key={item.id} style={{ borderBottom: '0.5px solid rgba(255,255,255,0.05)', background: i % 2 ? 'rgba(255,255,255,0.02)' : 'transparent' }}>
                  <td style={{ padding: '8px 10px' }}>{item.product_name}</td>
                  <td style={{ padding: '8px 10px', color: 'var(--color-text-secondary)', fontSize: 11 }}>{item.variant_sku}</td>
                  <td style={{ padding: '8px 10px', textAlign: 'center' }}>{fmt(item.quantity)}</td>
                  <td style={{ padding: '8px 10px' }}>{fmt(item.unit_price)}</td>
                  <td style={{ padding: '8px 10px', textAlign: 'center', color: '#FF9500' }}>{item.discount_percent > 0 ? item.discount_percent + '%' : '—'}</td>
                  <td style={{ padding: '8px 10px', fontWeight: 600 }}>{fmt(item.subtotal)}</td>
                  <td style={{ padding: '8px 10px', color: 'var(--color-text-secondary)' }}>{fmt(item.total_cost)}</td>
                  <td style={{ padding: '8px 10px', fontWeight: 600, color: item.profit >= 0 ? '#00C896' : '#FF3B3B' }}>{fmt(item.profit)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* پرداخت‌ها */}
      <div className="card p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-white">پرداخت‌های مشتری</h3>
          {inv.remaining_amount > 0 && (
            <button onClick={() => setPayForm(f => ({ ...f, show: true }))} className="text-xs text-brand hover:text-brand/80">+ ثبت پرداخت</button>
          )}
        </div>

        {payForm.show && (
          <div className="bg-white/5 rounded-xl p-4 mb-4 space-y-3">
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="label text-xs mb-1 block">روش پرداخت</label>
                <select value={payForm.method} onChange={e => setPayForm(f => ({ ...f, method: e.target.value }))} className="input text-xs">
                  <option value="cash">نقد</option>
                  <option value="transfer">حواله</option>
                  <option value="card">کارت به کارت</option>
                  <option value="online">آنلاین</option>
                  <option value="credit">نسیه</option>
                </select>
              </div>
              <div>
                <label className="label text-xs mb-1 block">مبلغ (ریال)</label>
                <input type="number" value={payForm.amount}
                  onChange={e => setPayForm(f => ({ ...f, amount: e.target.value }))}
                  placeholder={fmt(inv.remaining_amount)} className="input text-xs" />
              </div>
              <div>
                <label className="label text-xs mb-1 block">واریز به حساب</label>
                <select value={payForm.to_account_id} onChange={e => setPayForm(f => ({ ...f, to_account_id: e.target.value }))} className="input text-xs">
                  <option value="">انتخاب کنید...</option>
                  {accounts.filter(a => a.currency === 'IRR').map(a => (
                    <option key={a.id} value={a.id}>{a.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label text-xs mb-1 block">تاریخ</label>
                <input type="date" value={payForm.date} onChange={e => setPayForm(f => ({ ...f, date: e.target.value }))} className="input text-xs" />
              </div>
              <div className="col-span-2">
                <label className="label text-xs mb-1 block">شماره پیگیری</label>
                <input value={payForm.reference} onChange={e => setPayForm(f => ({ ...f, reference: e.target.value }))} className="input text-xs" placeholder="اختیاری" />
              </div>
            </div>
            {msg && <div className={`text-xs rounded-lg px-3 py-2 ${msg.type === 'success' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>{msg.text}</div>}
            <div className="flex gap-2">
              <button onClick={() => payMut.mutate({ invoice_id: id, ...payForm })} disabled={!payForm.amount || payMut.isPending} className="btn-primary text-xs px-4 py-2 disabled:opacity-50">ثبت</button>
              <button onClick={() => setPayForm(f => ({ ...f, show: false }))} className="btn-secondary text-xs px-4 py-2">انصراف</button>
            </div>
          </div>
        )}

        {inv.payments?.length === 0 ? (
          <div className="text-center py-4 text-gray-steel text-xs">پرداختی ثبت نشده</div>
        ) : (
          <div className="space-y-2">
            {inv.payments?.map(p => (
              <div key={p.id} className="flex items-center justify-between bg-white/5 rounded-lg px-3 py-2">
                <div>
                  <div className="text-xs text-white">{p.method_display} {p.to_account ? `→ ${p.to_account}` : ''}</div>
                  <div className="text-[10px] text-gray-steel">{p.date} {p.reference && `| ${p.reference}`} | {p.created_by}</div>
                </div>
                <div className="text-sm font-bold text-green-400">{fmt(p.amount)} ت</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// ─── فرم فاکتور جدید ─────────────────────────────────────────
function NewInvoiceForm({ onClose, onSuccess, prefillOrder }) {
  const { data: variants = [] } = useQuery({ queryKey: ['variants-list'], queryFn: () => api.get('/catalog/variants/').then(r => r.data) })
  const qc = useQueryClient()

  const [customerSearch, setCustomerSearch] = useState('')
  const [customer, setCustomer] = useState(prefillOrder ? { id: prefillOrder.customer_id, name: prefillOrder.customer_name, phone: prefillOrder.customer_phone } : null)
  const [showCustomerDrop, setShowCustomerDrop] = useState(false)

  const { data: customers = [] } = useQuery({
    queryKey: ['customer-search', customerSearch],
    queryFn: () => api.get('/accounting/customers/search/', { params: { q: customerSearch } }).then(r => r.data),
    enabled: customerSearch.length >= 2,
  })

  const [items, setItems] = useState(prefillOrder?.items?.map(i => ({
    variant_id: String(i.variant_id), quantity: String(i.quantity),
    unit_price: String(i.unit_price), discount_percent: '0',
  })) || [{ variant_id: '', quantity: '', unit_price: '', discount_percent: '0' }])

  const [hdr, setHdr] = useState({
    discount_amount: '0', shipping_cost: '0', tax_amount: '0',
    note: '', status: 'confirmed',
    order_id: prefillOrder?.id || '',
    source: prefillOrder ? 'order' : 'manual',
  })
  const [msg, setMsg] = useState(null)

  const createMut = useMutation({
    mutationFn: (d) => api.post('/accounting/sale-invoices/', d).then(r => r.data),
    onSuccess: (data) => {
      setMsg({ type: 'success', text: `فاکتور ${data.invoice_number} صادر شد` })
      qc.invalidateQueries(['sale-invoices'])
      qc.invalidateQueries(['pending-orders'])
      setTimeout(() => onSuccess?.(), 1500)
    },
    onError: (e) => setMsg({ type: 'error', text: e.response?.data?.error || 'خطا' }),
  })

  const calcSubtotal = () => items.reduce((s, it) => {
    const qty = Number(it.quantity) || 0
    const price = Number(it.unit_price) || 0
    const disc = Number(it.discount_percent) || 0
    return s + Math.round(qty * price * (1 - disc / 100))
  }, 0)

  const total = calcSubtotal() - Number(hdr.discount_amount || 0) + Number(hdr.shipping_cost || 0) + Number(hdr.tax_amount || 0)

  function handleSubmit() {
    if (!customer) return setMsg({ type: 'error', text: 'مشتری را انتخاب کنید' })
    if (items.some(it => !it.variant_id || !it.quantity || !it.unit_price)) return setMsg({ type: 'error', text: 'اطلاعات اقلام را کامل کنید' })
    createMut.mutate({
      customer_id: customer.id,
      customer_name: customer.name,
      customer_phone: customer.phone || '',
      ...hdr,
      items: items.map(it => ({ ...it, quantity: Number(it.quantity), unit_price: Number(it.unit_price), discount_percent: Number(it.discount_percent) })),
    })
  }

  return (
    <div className="space-y-4">
      {/* مشتری */}
      <div className="card p-5">
        <h3 className="text-sm font-semibold text-white mb-4">اطلاعات مشتری</h3>
        <div className="relative max-w-sm">
          <label className="label text-xs mb-1 block">جستجوی مشتری *</label>
          <input value={customerSearch} onChange={e => { setCustomerSearch(e.target.value); setShowCustomerDrop(true) }}
            onFocus={() => setShowCustomerDrop(true)}
            placeholder="نام یا شماره موبایل..." className="input text-sm" />
          {showCustomerDrop && customers.length > 0 && (
            <div className="absolute z-50 top-full right-0 left-0 mt-1 bg-navy border border-white/10 rounded-xl shadow-xl overflow-hidden">
              {customers.map(c => (
                <button key={c.id} className="w-full text-right px-4 py-3 hover:bg-white/5 border-b border-white/5 last:border-0"
                  onClick={() => { setCustomer(c); setCustomerSearch(c.name); setShowCustomerDrop(false) }}>
                  <div className="text-sm text-white">{c.name}</div>
                  <div className="text-xs text-gray-steel">{c.phone}</div>
                </button>
              ))}
            </div>
          )}
          {showCustomerDrop && <div className="fixed inset-0 z-40" onClick={() => setShowCustomerDrop(false)} />}
          {customer && <div className="text-xs text-green-400 mt-1">✓ {customer.name} | {customer.phone}</div>}
        </div>
      </div>

      {/* اقلام */}
      <div className="card p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-white">اقلام فاکتور</h3>
          <button onClick={() => setItems(i => [...i, { variant_id: '', quantity: '', unit_price: '', discount_percent: '0' }])}
            className="text-xs text-brand">+ افزودن کالا</button>
        </div>
        <div className="space-y-3">
          {items.map((item, idx) => (
            <div key={idx} className="bg-white/5 rounded-xl p-3">
              <div className="grid grid-cols-5 gap-3">
                <div className="col-span-2">
                  <label className="label text-[10px] mb-1 block">کالا *</label>
                  <select value={item.variant_id} onChange={e => setItems(i => i.map((it, j) => j === idx ? { ...it, variant_id: e.target.value } : it))} className="input text-xs">
                    <option value="">انتخاب...</option>
                    {variants.map(v => <option key={v.id} value={v.id}>{v.product_name} [{v.sku}]</option>)}
                  </select>
                </div>
                <div>
                  <label className="label text-[10px] mb-1 block">تعداد *</label>
                  <input type="number" value={item.quantity} onChange={e => setItems(i => i.map((it, j) => j === idx ? { ...it, quantity: e.target.value } : it))} className="input text-xs" />
                </div>
                <div>
                  <label className="label text-[10px] mb-1 block">قیمت واحد *</label>
                  <input type="number" value={item.unit_price} onChange={e => setItems(i => i.map((it, j) => j === idx ? { ...it, unit_price: e.target.value } : it))} className="input text-xs" />
                </div>
                <div>
                  <label className="label text-[10px] mb-1 block">تخفیف %</label>
                  <input type="number" min="0" max="100" value={item.discount_percent} onChange={e => setItems(i => i.map((it, j) => j === idx ? { ...it, discount_percent: e.target.value } : it))} className="input text-xs" />
                </div>
              </div>
              <div className="flex items-center justify-between mt-2">
                <div className="text-xs text-gray-steel">
                  جمع: <span className="text-white font-bold">{fmt(Math.round((Number(item.quantity) || 0) * (Number(item.unit_price) || 0) * (1 - (Number(item.discount_percent) || 0) / 100)))}</span> ت
                </div>
                {items.length > 1 && <button onClick={() => setItems(i => i.filter((_, j) => j !== idx))} className="text-xs text-red-400">× حذف</button>}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* هزینه‌های اضافی */}
      <div className="card p-5">
        <h3 className="text-sm font-semibold text-white mb-4">تخفیف و هزینه‌های اضافی</h3>
        <div className="grid grid-cols-4 gap-4">
          <div>
            <label className="label text-xs mb-1 block">تخفیف کل (ریال)</label>
            <input type="number" value={hdr.discount_amount} onChange={e => setHdr(h => ({ ...h, discount_amount: e.target.value }))} className="input text-sm" />
          </div>
          <div>
            <label className="label text-xs mb-1 block">هزینه ارسال (ریال)</label>
            <input type="number" value={hdr.shipping_cost} onChange={e => setHdr(h => ({ ...h, shipping_cost: e.target.value }))} className="input text-sm" />
          </div>
          <div>
            <label className="label text-xs mb-1 block">مالیات (ریال)</label>
            <input type="number" value={hdr.tax_amount} onChange={e => setHdr(h => ({ ...h, tax_amount: e.target.value }))} className="input text-sm" />
          </div>
          <div>
            <label className="label text-xs mb-1 block">وضعیت اولیه</label>
            <select value={hdr.status} onChange={e => setHdr(h => ({ ...h, status: e.target.value }))} className="input text-sm">
              <option value="draft">پیش‌نویس</option>
              <option value="confirmed">تأیید شده</option>
            </select>
          </div>
        </div>
        <div className="mt-3">
          <label className="label text-xs mb-1 block">توضیحات</label>
          <input value={hdr.note} onChange={e => setHdr(h => ({ ...h, note: e.target.value }))} className="input text-sm" />
        </div>
        <div className="mt-4 text-left">
          <div className="text-xs text-gray-steel">مبلغ نهایی فاکتور:</div>
          <div className="text-2xl font-bold text-brand">{fmt(total)} ریال</div>
        </div>
      </div>

      {msg && <div className={`rounded-lg px-4 py-3 text-sm ${msg.type === 'success' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>{msg.text}</div>}

      <div className="flex gap-3">
        <button onClick={handleSubmit} disabled={createMut.isPending} className="btn-primary flex-1 py-3 disabled:opacity-50">
          {createMut.isPending ? 'در حال صدور...' : 'صدور فاکتور'}
        </button>
        <button onClick={onClose} className="btn-secondary px-6 py-3">انصراف</button>
      </div>
    </div>
  )
}

// ─── صفحه اصلی ───────────────────────────────────────────────
export default function SaleInvoicePage() {
  const [view, setView] = useState('list')
  const [selectedId, setSelectedId] = useState(null)
  const [prefillOrder, setPrefillOrder] = useState(null)
  const [tab, setTab] = useState('invoices')

  const { data: invoices = [], isLoading } = useQuery({
    queryKey: ['sale-invoices'],
    queryFn: () => api.get('/accounting/sale-invoices/').then(r => r.data),
    enabled: view === 'list',
  })
  const { data: pendingOrders = [] } = useQuery({
    queryKey: ['pending-orders'],
    queryFn: () => api.get('/accounting/pending-orders/').then(r => r.data),
    enabled: view === 'list',
  })

  return (
    <div className="container-main py-8 max-w-6xl">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          {view !== 'list' && <button onClick={() => { setView('list'); setPrefillOrder(null) }} className="text-gray-steel hover:text-white text-sm">← برگشت</button>}
          <h1 className="font-display font-bold text-2xl text-white">
            {view === 'list' ? 'فاکتورهای فروش' : view === 'new' ? 'فاکتور جدید' : 'جزئیات فاکتور'}
          </h1>
        </div>
        {view === 'list' && <button onClick={() => setView('new')} className="btn-primary text-sm px-4 py-2">+ فاکتور جدید</button>}
      </div>

      {view === 'list' && (
        <>
          {/* تب‌ها */}
          <div className="flex gap-2 mb-4 border-b border-white/10">
            {[['invoices', `فاکتورها (${invoices.length})`], ['pending', `سفارشات در انتظار (${pendingOrders.filter(o => !o.has_invoice).length})`]].map(([k, v]) => (
              <button key={k} onClick={() => setTab(k)}
                className={`text-sm px-5 py-2.5 rounded-t-lg border-b-2 transition-all ${tab === k ? 'border-brand text-white bg-brand/10' : 'border-transparent text-gray-steel hover:text-white'}`}>
                {v}
              </button>
            ))}
          </div>

          {tab === 'invoices' && (
            <div className="card p-5">
              {isLoading ? <div className="text-center py-8 text-gray-steel">در حال بارگذاری...</div>
                : invoices.length === 0 ? (
                  <div className="text-center py-12">
                    <div className="text-4xl mb-3">🧾</div>
                    <div className="text-gray-steel text-sm mb-4">هنوز فاکتوری صادر نشده</div>
                    <button onClick={() => setView('new')} className="btn-primary text-sm px-6 py-2">+ صدور اولین فاکتور</button>
                  </div>
                ) : (
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                    <thead>
                      <tr style={{ borderBottom: '0.5px solid rgba(255,255,255,0.1)' }}>
                        {['شماره فاکتور', 'مشتری', 'تاریخ', 'وضعیت', 'مبلغ نهایی', 'پرداخت شده', 'مانده', 'سود', ''].map(h => (
                          <th key={h} style={{ padding: '8px 12px', textAlign: 'right', color: 'var(--color-text-secondary)', fontWeight: 500, whiteSpace: 'nowrap' }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {invoices.map((inv, i) => (
                        <tr key={inv.id} style={{ borderBottom: '0.5px solid rgba(255,255,255,0.05)', background: i % 2 ? 'rgba(255,255,255,0.02)' : 'transparent' }}>
                          <td style={{ padding: '10px 12px', fontWeight: 600, color: '#0066FF' }}>{inv.invoice_number}</td>
                          <td style={{ padding: '10px 12px' }}>
                            <div>{inv.customer_name}</div>
                            <div style={{ fontSize: 11, color: 'var(--color-text-secondary)' }}>{inv.customer_phone}</div>
                          </td>
                          <td style={{ padding: '10px 12px', color: 'var(--color-text-secondary)', fontSize: 11 }}>{inv.created_at}</td>
                          <td style={{ padding: '10px 12px' }}>
                            <span style={{ color: STATUS_COLORS[inv.status], background: STATUS_COLORS[inv.status] + '20', padding: '2px 8px', borderRadius: 20, fontSize: 11 }}>{inv.status_display}</span>
                          </td>
                          <td style={{ padding: '10px 12px', fontWeight: 600 }}>{fmt(inv.total_amount)} ت</td>
                          <td style={{ padding: '10px 12px', color: '#00C896' }}>{fmt(inv.paid_amount)} ت</td>
                          <td style={{ padding: '10px 12px', color: inv.remaining_amount > 0 ? '#FF3B3B' : '#00C896', fontWeight: inv.remaining_amount > 0 ? 700 : 400 }}>
                            {inv.remaining_amount > 0 ? fmt(inv.remaining_amount) + ' ت' : '✓ تسویه'}
                          </td>
                          <td style={{ padding: '10px 12px', color: inv.gross_profit >= 0 ? '#00C896' : '#FF3B3B' }}>{fmt(inv.gross_profit)} ت</td>
                          <td style={{ padding: '10px 12px' }}>
                            <button onClick={() => { setSelectedId(inv.id); setView('detail') }} className="text-xs text-brand hover:text-brand/80">مشاهده</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
            </div>
          )}

          {tab === 'pending' && (
            <div className="space-y-3">
              {pendingOrders.filter(o => !o.has_invoice).length === 0 ? (
                <div className="card p-12 text-center text-gray-steel text-sm">سفارش در انتظاری وجود ندارد</div>
              ) : pendingOrders.filter(o => !o.has_invoice).map(order => (
                <div key={order.id} className="card p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-3">
                        <span className="font-bold text-white text-sm">{order.order_number}</span>
                        <span style={{ color: '#FF9500', background: '#FF950020', padding: '2px 8px', borderRadius: 20, fontSize: 11 }}>{order.status_display}</span>
                        <span style={{ color: '#0066FF', background: '#0066FF20', padding: '2px 8px', borderRadius: 20, fontSize: 11 }}>{order.order_type_display}</span>
                      </div>
                      <div className="text-xs text-gray-steel mt-1">{order.customer_name} | {order.customer_phone} | {order.created_at}</div>
                      <div className="flex gap-4 mt-2">
                        {order.items?.slice(0, 3).map((item, i) => (
                          <span key={i} className="text-xs text-white bg-white/5 px-2 py-1 rounded">
                            {item.product_name} × {item.quantity}
                          </span>
                        ))}
                        {order.items?.length > 3 && <span className="text-xs text-gray-steel">+{order.items.length - 3} مورد دیگر</span>}
                      </div>
                    </div>
                    <div className="text-left">
                      <div className="text-sm font-bold text-white">{fmt(order.total_amount)} ت</div>
                      <button
                        onClick={() => { setPrefillOrder(order); setView('new') }}
                        className="btn-primary text-xs px-4 py-2 mt-2">
                        صدور فاکتور
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {view === 'new' && <NewInvoiceForm onClose={() => { setView('list'); setPrefillOrder(null) }} onSuccess={() => { setView('list'); setPrefillOrder(null) }} prefillOrder={prefillOrder} />}
      {view === 'detail' && selectedId && <InvoiceDetail id={selectedId} onClose={() => setView('list')} />}
    </div>
  )
}
